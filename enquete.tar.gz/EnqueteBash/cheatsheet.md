Jouer avec du texte sur la ligne de commande
=======================================

La ligne de commande (aussi appelée interface de ligne de commande, ou CLI, ou parfois terminal) est une interface en texte brut permettant d'exécuter des commandes sur un ordinateur. Si vous avez déjà vu un film sur les hackers des années 1980, comme *WarGames*, où ils fixent une invite sur un écran noir et saisissent des commandes une par une, c'est en gros ça.

Vous avez une invite, vous pouvez saisir une commande et appuyer sur « Entrée » pour l'exécuter. Voici un exemple de commande :

	touch newfile.txt

Cette commande crée un fichier nommé « newfile.txt ».

Quelques détails supplémentaires
--------------------

Les commandes se présentent généralement sous la forme suivante :

	[nom de la commande] [option] [option] [option] ...

L'invite indique également le répertoire dans lequel vous vous trouvez. Chaque fois que vous exécutez une commande, vous le faites depuis un répertoire spécifique. Ceci est important, car lorsque vous exécutez une commande impliquant un nom de fichier ou de répertoire, vous pouvez le spécifier de deux manières :

#### Chemins relatifs

Spécifier un chemin relatif pour un fichier ou un répertoire signifie que vous spécifiez son emplacement par rapport au répertoire dans lequel vous vous trouvez. Par exemple, imaginons que vous vous trouviez dans le sous-répertoire « videos » du répertoire « files ». L'invite suivante s'affichera :

	/files/videos$

Si vous exécutez une commande telle que « touch newfile.txt », le fichier « newfile.txt » sera créé dans le répertoire courant. Les chemins relatifs ne commencent pas par un slash.

#### Chemins absolus

Spécifier un chemin absolu pour un fichier ou un répertoire signifie que vous spécifiez son emplacement sur l'ordinateur de manière absolue, en commençant par le niveau supérieur. Par exemple, supposons que vous vous trouviez à nouveau dans le sous-répertoire « videos » du répertoire « files ».

	/files/videos$

Si vous exécutez une commande telle que « touch /files/music/newfile.txt », le fichier « newfile.txt » sera créé dans un autre dossier, le sous-dossier « music » du dossier « files ». *Les chemins absolus commencent par une barre oblique.*

Si vous utilisez un chemin absolu, la commande aura le même effet quel que soit le répertoire d'exécution.

Ces deux commandes produiront le même résultat depuis le répertoire « /files/videos » :

	/files/videos$ rm video.mp4
	(Ceci supprimera le fichier « video.mp4 » du répertoire courant.)

	/files/videos$ rm /files/videos/video.mp4
	(Ceci supprimera « video.mp4 » du répertoire /files/videos/, qui se trouve être le répertoire courant.)

Les deux mêmes commandes n'auront pas le même résultat si vous vous trouvez dans un répertoire différent :

	/files/texte$ rm vidéo.mp4
	(Cette commande tentera de supprimer le fichier vidéo.mp4 du sous-répertoire « texte », car il s'agit du répertoire courant.)

	/files/texte$ rm /files/videos/vidéo.mp4
	(Cette commande supprimera le fichier du répertoire /files/videos/, même s'il ne s'agit pas du répertoire courant.)

À retenir :

**Commencer un chemin par une barre oblique** signifie que vous souhaitez indiquer le chemin complet et ignorer le répertoire dans lequel vous vous trouvez.
**Ne pas commencer un chemin par une barre oblique** signifie que vous souhaitez indiquer le chemin à partir du répertoire dans lequel vous vous trouvez.

En cas de doute sur le répertoire dans lequel vous vous trouvez, vous pouvez utiliser la commande « pwd » (Imprimer le répertoire de travail) pour obtenir le chemin absolu du répertoire courant.

	~$ pwd
	/Users/Noah

Modèles de fichiers
-------------

Dans la plupart des cas, lorsque vous devez spécifier un nom de fichier ou de répertoire, vous pouvez également spécifier un **modèle** général pouvant correspondre à plusieurs fichiers. Cette méthode présente de nombreuses possibilités, mais la version la plus simple consiste à utiliser l'astérisque (*), qui correspond à tout. On l'appelle aussi un caractère générique.

Supprimer tout fichier du répertoire courant
	/files$ rm *

Supprimer tout fichier se terminant par « .txt »
	/files$ rm *.txt

Supprimer tout fichier commençant par « data »
	/files$ rm data*

Navigation
----------

Les deux commandes principales pour naviguer dans le répertoire de l'invite sont « cd » et « ls ».

« cd » permet de changer de répertoire et doit être suivi du répertoire souhaité. Vous pouvez indiquer un chemin absolu ou relatif.

Vous serez alors redirigé vers /files/videos
	/files$ cd videos 
	/files/videos$

Vous serez alors redirigé vers /videos, puis vers le sous-répertoire Vines
	/files$ cd /videos
	/videos$ cd vines
	/videos/vines$

Vous pouvez accéder à plusieurs niveaux simultanément si vous le souhaitez.

Vous serez alors redirigé vers /files/videos/short
	/files$ cd videos/short

Vous pouvez utiliser « cd .. » pour remonter d'un niveau jusqu'au répertoire parent.

Vous serez alors redirigé vers /files
	/files/videos$ cd ..

« ls » listera les fichiers du répertoire actuel. Cela permet de savoir où vous vous trouvez, quels fichiers existent et quels sous-dossiers existent.

	/photos$ ls 
	miniatures photo1.jpg photo2.jpg

L'utilisation de « ls -l » permet d'imprimer la liste verticalement, avec de nombreuses informations supplémentaires sur la taille du fichier, les autorisations et la date de dernière modification :

	/photos$ ls -l
	-rw-rw-r-- 1 noah noah 58133 22 oct. 17:13 photo1.jpg
	-rw-rw-r-- 1 noah noah 75640 22 oct. 17:13 photo2.jpg
	drwxrwxr-x 2 noah noah 4096 22 oct. 17:13 miniatures

Lorsque vous saisissez un nom de répertoire ou de fichier, vous pouvez appuyer sur la touche « Tab » pour la saisie semi-automatique, si possible. Par exemple, dans le dossier /photos, si vous saisissez :

	/photos$ cd jeu

et appuyez sur « Tab », le reste sera complété et vous verrez :

	/photos$ cd miniatures

Cependant, si le nombre de fichiers/répertoires correspondant à ce que vous avez saisi jusqu'à présent est supérieur au nombre possible, cela ne fonctionnera pas. Si vous saisissez :

	/photos$ rm pho

et appuyez sur « Tab », rien ne se passera, car vous pourriez être en route vers « photo1.jpg » OU « photo2.jpg ».

Sortie de commande
--------------

Les commandes que nous allons aborder affichent toutes leurs résultats sous forme de texte. Lorsque vous exécutez la commande en appuyant sur « Entrée », plusieurs lignes de sortie s'affichent sur des lignes supplémentaires sous l'invite. Par exemple, « head [fichier] » affiche les 10 premières lignes d'un fichier.

	/files$ noms_têtes.txt
	Dan Sinker
	Erika Owens
	Noah Veltman
	Annabel Church
	Friedrich Lindenberg
	Sonya Song
	Mike Tigas
	Brian Abelson
	Manuel Aristaran
	Stijn Debrouwere
	/files$

Remarque : après avoir affiché sa sortie, une nouvelle invite de commande s'affiche. Ce mode d'affichage est utile pour une simple consultation, mais il est souvent utile d'effectuer l'une des deux opérations suivantes : **envoyer la sortie vers un fichier** ou **envoyer la sortie vers une autre commande en tant qu'entrée**.

### Envoi de la sortie vers un fichier

Vous pouvez envoyer la sortie vers un nouveau fichier de cette manière :

	/files$ head names.txt > first10names.txt

Si le fichier first10names.txt n'existe pas, il sera créé. S'il existe déjà, il sera écrasé.

Vous pouvez ajouter la sortie à la fin d'un fichier existant de cette manière :

	/files$ head names.txt >> allnames.txt

La sortie sera ajoutée sous forme de 10 nouvelles lignes à la fin du fichier allnames.txt.

### Envoyer la sortie vers une autre commande en tant qu'entrée

Vous pouvez envoyer la sortie vers une autre commande à l'aide du symbole pipe (|). La commande « grep » recherche des correspondances dans du texte (nous y reviendrons plus tard). Vous pouvez donc utiliser cette commande pour obtenir les 10 premières lignes d'un fichier, puis rechercher « Steve » dans ces 10 lignes :

	/files$ noms_têtes.txt | grep "Steve"

Cela revient à faire la même chose :

	/files$ noms_têtes.txt > fichier_temporaire.txt
	/files$ grep "Steve" fichier_temporaire.txt

Mais au lieu d'envoyer d'abord la sortie vers un fichier, puis d'exécuter la deuxième commande sur ce fichier, vous envoyez la sortie directement de la première commande vers la deuxième. Vous pouvez enchaîner autant de commandes que vous le souhaitez :

	/files$ grep "États-Unis" adresses.csv | grep "Californie" | head

Cette fonction recherche dans le fichier addresses.csv les lignes contenant l'expression « États-Unis », puis les lignes contenant le mot « Californie », puis affiche les 10 premières correspondances.

Grep
----

La commande « grep » vous permet de rechercher une expression dans un ou plusieurs fichiers. Par défaut, elle affiche chaque ligne correspondant à votre recherche.

Afficher les lignes contenant le mot « darkwing » :

	/files$ grep "darkwing" famousducks.txt

Comme ci-dessus, mais la recherche ne tient pas compte de la casse :

	/files$ grep -i "darkwing" famousducks.txt

Trouver des correspondances pour le *mot* exact « Donald » dans un fichier. Les mots contenant « Donald », comme « McDonald », ne sont pas pris en compte :

	grep -w "Donald" famousducks.txt

Trouver des correspondances pour « McDuck » dans chaque fichier du répertoire courant :

	grep "McDuck" *

Trouver des correspondances pour « McDuck » dans chaque fichier du répertoire courant ET dans chaque sous-répertoire, jusqu'en bas :

	grep -r "McDuck" *

Pour chaque correspondance pour « Howard », afficher cette ligne ET les 4 lignes suivantes (5 lignes au total) :

	grep -A 4 "Howard" famousducks.txt

Pour chaque correspondance avec « Howard », imprimez cette ligne ET les 4 lignes précédentes (5 lignes au total) :

	grep -B 4 "Howard" famousducks.txt

Pour chaque correspondance avec « Howard », imprimez cette ligne ET les 4 lignes précédentes ET les 4 lignes suivantes (9 lignes au total) :

	grep -C 4 "Howard" famousducks.txt

Au lieu d'afficher les lignes correspondantes, imprimez les noms de fichiers correspondant à votre recherche :

	grep -l "Daffy" *

Obtenez simplement le nombre de correspondances :

	grep -c "Daffy" *

Affichez les numéros de ligne avec les lignes correspondantes :

	grep -n "Daffy" famousducks.txt

Cat
---


La commande « cat » combinera plusieurs fichiers. Elle affichera trois fichiers d'affilée, comme s'il s'agissait d'un seul fichier :

	cat dinde.txt canard.txt poulet.txt

N'oubliez pas que cette commande affichera simplement le résultat dans votre terminal. Vous souhaiterez probablement créer un nouveau fichier qui les combinera :

	cat dinde.txt canard.txt poulet.txt > turducken.txt

turducken.txt contiendra toutes les lignes de turkey.txt, suivies de toutes les lignes de duck.txt, puis de toutes les lignes de chicken.txt.

Pour combiner TOUS les fichiers d'un répertoire, vous pouvez utiliser un caractère générique :

	cat * > allfilescombined.txt

Head
----

La commande « head » affiche les 10 premières lignes d'un fichier :

	/files$ head names.txt

Vous pouvez également spécifier un nombre de lignes différent. Cela affichera les 15 premières lignes d'un fichier :

	/files$ head -n 15 names.txt

Si vous souhaitez afficher l'intégralité du fichier sans les 15 DERNIÈRES lignes, vous pouvez indiquer un nombre négatif :

	/files$ head -n -15 names.txt

L'une des utilisations intéressantes de head est de pouvoir consulter rapidement le contenu d'un fichier texte volumineux sans avoir à attendre qu'un éditeur de texte le charge. C'est un atout majeur pour un fichier de 1 Go !

Tail
----

La commande « tail » est l'inverse de « head ». Elle affiche les 10 dernières lignes d'un fichier :

	/files$ tail names.txt

Cette commande affiche les 15 dernières lignes d'un fichier :

	/files$ tail -n 15 names.txt

Si vous souhaitez afficher l'intégralité du fichier sans les 15 premières lignes, vous pouvez ajouter un signe plus :

	/files$ tail -n +15 names.txt

Cette commande est utile, par exemple, pour supprimer une ligne d'en-tête d'un fichier CSV :

	/files$ tail -n +1 names.txt > names-no-header.txt

Divers
-------------

Si vous souhaitez simplement afficher l'intégralité du contenu d'un fichier dans votre terminal, vous pouvez utiliser « cat » sans le combiner avec quoi que ce soit. Cela va à l'encontre de l'objectif de « cat », mais c'est une astuce pratique.

	/files$ adresse_cat.txt
	1600 Pennsylvania Avenue
	Washington, DC 20500

Si vous voulez aller plus loin et ouvrir un fichier dans un éditeur de texte intégré à votre terminal, vous pouvez essayer « nano » :

	/files$ adresse_nano.txt

Combien de lignes contient le fichier names.txt ?

	/files$ wc -l names.txt
	18

Expressions régulières
-------------------

Lors d'une recherche avec une commande comme « grep », vous pouvez rechercher un terme simple composé uniquement de lettres, de chiffres et d'espaces. Mais pour rechercher un motif, vous pouvez utiliser une **expression régulière**. Les expressions régulières utilisent des caractères spéciaux pour représenter des motifs, comme « n'importe quel nombre », « n'importe quelle lettre », « X ou Y », « au moins trois lettres minuscules », etc.

Nous ne nous intéresserons pas aux tenants et aboutissants pour l'instant, mais un opérateur utile est le point (.). En langage d'expression régulière, cela signifie « Un caractère quelconque ». Vous pouvez donc rechercher quelque chose comme :

	/files$ grep -i "car.s" dictionary.txt

Cela correspondrait à des mots comme « cards », « carts », « cares », etc. Cela correspondrait également au milieu de l'expression « scar story » (CAR S), car « n'importe quel caractère » signifie N'IMPORTE QUEL caractère, y compris un espace ou un signe de ponctuation.

Un autre exemple :

	/files$ grep -i ".e.st" dictionary.txt

Cela correspondrait à des éléments tels que « least », « beast » et « heist ».

Plusieurs façons de dépecer un chat
------------------------------

Il existe souvent de nombreuses commandes ou combinaisons de commandes tout aussi légitimes pour atteindre le même objectif.

Exemple :

	/files$ head -n 12 names.txt | tail -n 5
	(Afficher les 12 premières lignes, puis les 5 dernières)

équivalent à :

	/files$ tail -n +7 names.txt | head -n 5
	(Afficher tout sauf les 7 premières lignes, puis les 5 premières)

équivalent à :

	/files$ tail -n +7 names.txt > temporaryfile.txt
	/files$ head -n 5 temporaryfile.txt
	/files$ rm temporaryfile.txt
	(Enregistrer tout sauf les 7 premières lignes dans un fichier temporaire, puis afficher les 5 premières lignes, puis supprimer le fichier temporaire)
